---
layout: blog
title: 7 fun facts about Indian Food
date: 2020-09-27T16:02:02.302Z
---
Here are the 7 fun facts about Indian Food;

1. India is called the Land of Spices. No country in the world produces as many varieties of spices as India.

2. Greek, Roman and Arab traders have contributed a lot to the first foreign flavours in Indian cuisine.

3. The first Indian restaurant in the USA was opened in the mid 1960s. Today, there are around 80,000 Indian restaurants in America.

4. Pepper is known as the king of spices because it goes well with everything

5. Indian food system classifies food into three categories - Saatvic (fresh vegetables and juice), Raajsic (oily and spicy food) and Taamsic (Meat and liquor).

6. According to Indian Food Theory, our food has 6 different flavours: sweet, salty, bitter, sour, astringent and spicy.

7. Staple ingredients of Indian cuisine like potato, tomato and chilli don't have Indian origin. They were brought to India by the Portuguese.