---
layout: blog
title: How to make sandwiches like a pro
date: 2020-09-27T15:49:25.531Z
---
<!--StartFragment-->

This is the post body where I write about how to make sandwich so good that even impress Gordon Ramsay.

<!--EndFragment-->