---
layout: blog
title: 6 cool facts about Indian foods
date: 2020-09-27T16:29:24.658Z
---
Here are the 6 cool facts about Indian foods:

1. Indian food is awesome!
2. Indian food is awesome!
3. Indian food is awesome!
4. Indian food is awesome!
5. Indian food is awesome!
6. Indian food is awesome!





