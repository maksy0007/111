---
layout: blog
title: Another post from Netlify CMS
date: 2020-09-27T16:02:02.302Z
---
This post is written using Netlify CMS and I didn't have to open the text editor!